﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Diagnostics;
using System.Numerics;
using static System.Runtime.InteropServices.JavaScript.JSType;
using static STS.UnitList;

namespace STS
{



    internal class Program
    {

 
        public void Printscreen() //UI 프레임을 호출하는 함수
        {
            int x = 0;
            int y = 0;
            int garo = 100;
            int sero = 28;

            for (int i = 0; i < garo; i++)
            {
                Console.SetCursorPosition(x + i, y);
                Console.Write("=");
                Console.SetCursorPosition(x + i, sero);
                Console.Write("=");
            }
            for (int i = 0; i < sero + 1; i++)
            {
                Console.SetCursorPosition(x, y + i);
                Console.Write('|');
                Console.SetCursorPosition(garo, y + i);
                Console.Write('|');
            }
        }

        public void Drowcard(Card C, int Selet) //입력받은 번호의 카드를 그려주는 함수
        {
            int x = 2;
            int y = 20;
            int maxhand = 5;


            for (int h = 1; h < maxhand; h++)
            {

                foreach(var card in _PlayerCardlist)
                { 
                }
                y = 20;

                if (Selet == h && Selet > 0)
                {
                    y = y - 5;
                }
                /*for(int i=0; i<15; i++)
                //{
                //    Console.SetCursorPosition(x + 1, y + 1);
                //    Console.Write(C.CardName);
                //    Console.SetCursorPosition(x + 1, y + 2);
                //    Console.Write($"코스트 : {C.CardCost}");
                //    Console.SetCursorPosition(x + 1, y + 3);
                //    Console.Write($"데미지 : {C.CardDMG}");
                //    Console.SetCursorPosition(x+i, y);
                //    Console.Write('=');
                //    Console.SetCursorPosition(x - 1, y + i);
                //    Console.Write('|');
                //    Console.SetCursorPosition(x+i, y +14);
                //    Console.Write('=');
                //    Console.SetCursorPosition(x + 14, y + i);
                //    Console.Write('|');

                }*/
                Console.SetCursorPosition(x + 1, y + 1);
                Console.Write(C.CardName);
                Console.SetCursorPosition(x + 1, y + 2);
                Console.Write($"코스트 : {C.CardCost}");
                Console.SetCursorPosition(x + 1, y + 3);
                Console.Write($"데미지 : {C.CardDMG}");
                if (C.Efchak > 0)
                {
                    Console.SetCursorPosition(x + 1, y + 4);
                    Console.Write("특수효과");
                    Console.SetCursorPosition(x + 1, y + 5);
                    C.EfCard();
                }



                Console.SetCursorPosition(x, y);
                Console.Write("===============");
                Console.SetCursorPosition(x, y + 6);
                Console.Write("===============");
                for (int i = 0; i < 7; i++)
                {
                    Console.SetCursorPosition(x - 1, y + i);
                    Console.Write('|');
                    Console.SetCursorPosition(x + 14, y + i);
                    Console.Write('|');
                }
                x = x + 18;
            }
        }
        static void Main(string[] args)
        {

            Card A = new Card("대단원의 막", 20, 5, 1);
            Card B = new Card("방패 밀치기", 20, 5, 0);
            Card C = new Card("신성한 폭발", 20, 5, 2);
            
            Program program = new Program();
            UnitList.Player player1 = new UnitList.Player("대머리", 20, 30, 50);
            int selectcard = 0;
            bool triger = true;
            player1.GetCard(A);
            player1.GetCard(A);
            player1.GetCard(A);
            player1.GetCard(B);
            player1.GetCard(B);
            player1.GetCard(B);
            player1.GetCard(B);
            program.Drowcard(C, selectcard);
            program.Printscreen();
            ConsoleKeyInfo input;

            while (triger)
            {


                input = Console.ReadKey();
                switch (input.Key)
                {
                    case ConsoleKey.LeftArrow:
                        if (selectcard >= 1)
                        {
                            Console.Clear();

                            selectcard--;
                            program.Printscreen();
                            program.Drowcard(C, selectcard);
                        }
                        break;

                    case ConsoleKey.RightArrow:
                        if (selectcard <= 5)
                        {
                            Console.Clear();
                            selectcard++;
                            program.Printscreen();
                            program.Drowcard(C, selectcard);
                        }
                        break;
                }
            }


            Console.Clear();
            program.Drowcard(A, selectcard);

            Console.Clear();

            program.Printscreen();
            program.PlayerPrint();
            program.Drowcard(A, selectcard);

        }







    }
}
