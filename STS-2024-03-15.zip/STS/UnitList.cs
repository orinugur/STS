﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace STS
{


    public class UnitList
    {
        public abstract class Unit
        {
            public abstract string UnitName { get; }
            public abstract int UnitHp { get; }
            public abstract int UnitAtk { get; }
            public abstract int UnitCost { get; }
            public abstract int CardDMG { get; }


        }

        public class Player : Unit
        {
            public override string UnitName { get; }
            public override int UnitHp { get; }
            public override int UnitAtk { get; }
            public override int UnitCost { get; }
            public override int CardDMG { get; }

            public Player(string UnitName, int UnitHp, int UnitAtk, int CardDMG)
            {
            }

            LinkedList<Card> _PlayerCardlist = new LinkedList<Card>();
            public void GetCard(Card card)
            {
                _PlayerCardlist.AddLast(card);
            }
            public void RemovedCard(Card card)
            {
                _PlayerCardlist.Remove(card);
            }


        }

    }
}
