﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Numerics;
using System.Text;
using System.Threading.Tasks;

namespace STS
{

    public class Card
    {
        public string CardName { get; }
        public int CardDMG { get; }
        public int CardCost { get; }

        public int Efchak { get; }

        public void EfCard() //특수카드인지 체크
        {
            if (Efchak==1) //1번 특수카드일시 cost를  회복한다는 문구를 출력
            {
                Ef_Costrecovery();
            }
            if(Efchak==2)
            {
                Ef_Hprecovery(); //2번 특수카드일시 Hp를 회복한다는 문구를 출력
            }

        }
        public void Ef_Costrecovery()
        {
            Console.Write("코스트를 회복");
        }
        public void Ef_Hprecovery()
        {
            Console.Write("체력을 회복");
        }
        
        public Card(string name, int Cost, int DMG ,int Ef)
        {
            CardName = name;
            CardDMG = Cost;
            CardCost = DMG;
            Efchak = Ef;


        }

    }

    internal class CardList
    {


    }

}